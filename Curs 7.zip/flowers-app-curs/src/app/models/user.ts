export class User {
    id?: number;
    username: string;
    userRole?: string;
    token?: string;
}

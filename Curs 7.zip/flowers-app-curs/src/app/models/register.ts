export class Register {
    firstName?: string;
    lastName?: string;
    username: string;
    email: string;
    password: string;
}

export class Flower {
    id?: number;
    name: string;
    colors: string;
    smellLevel: number;
    numberOfComments: number;
}

export class PaginatedFlowers {
    currentPage: number;
    numberOfPages: number;
    entries: Flower[];
}

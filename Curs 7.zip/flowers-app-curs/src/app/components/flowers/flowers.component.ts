import { Component, OnInit } from '@angular/core';
import { Flower } from 'src/app/models/flower';
import { FlowerService } from 'src/app/services/flowers.service';

@Component({
  selector: 'app-flowers',
  templateUrl: './flowers.component.html',
  styleUrls: ['./flowers.component.scss']
})
export class FlowersComponent implements OnInit {

    public flowers: any = null;
    public displayedColumns: string[] = ['name', 'colors', 'smellLevel'];

    constructor(private flowerService: FlowerService) {
        this.getAllFlowers();
      }

    ngOnInit() {
    }

    getAllFlowers() {
        // this.flowers = []
        this.flowerService.getAllFlowers().subscribe(f => {
            this.flowers = f;
            console.log(f);
        });
    }
}

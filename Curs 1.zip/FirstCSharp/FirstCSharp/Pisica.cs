﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstCSharp
{
    class Pisica
    {
        //private string nume;
        public string Nume
        {
            get; set;
            //get
            //{
            //    return nume;
            //}
            //set
            //{
            //    nume = value;
            //}
        }

        //public Pisica()
        //{

        //}

        //public Pisica(string nume)
        //{
        //    this.Nume = nume;
        //}
    }
}

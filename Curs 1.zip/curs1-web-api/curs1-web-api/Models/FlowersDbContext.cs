﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs1_web_api.Models
{
    public class FlowersDbContext : DbContext
    {
        public FlowersDbContext(DbContextOptions<FlowersDbContext> options) : base(options)
        {
        }

        public DbSet<Flower> Flowers { get; set; }
    }
}

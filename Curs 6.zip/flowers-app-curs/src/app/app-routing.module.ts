import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { FlowersComponent } from './components/flowers/flowers.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
       {
          path: 'flowers',
          component: FlowersComponent,
       }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

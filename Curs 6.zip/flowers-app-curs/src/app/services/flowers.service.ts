import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Flower } from '../models/flower';
import { map } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class FlowerService {
    // private flowersSubject: BehaviorSubject<any>;
    public flowers: any;

    constructor(private http: HttpClient) {
        // this.flowersSubject = new BehaviorSubject<any>(null);
    }

    getAllFlowers() : Observable<any> {
        return this.http.get<any>(
            `https://localhost:44365/api/flowers`);

        // return this.http.get<any>(`https://localhost:44365/api/flowers`)
        //     .pipe(map(response => {
        //         this.flowers = response;
        //         this.flowersSubject.next(this.flowers);
        //         return response;
        //     }));
    }
}
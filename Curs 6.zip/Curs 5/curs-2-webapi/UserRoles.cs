﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs_2_webapi
{
    public static class UserRoles
    {
        public const string Regular = "Regular";
    }
}

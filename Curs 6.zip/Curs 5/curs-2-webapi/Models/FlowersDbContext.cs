﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace curs_2_webapi.Models
{
    // DbContext = Unit of Work
    public class FlowersDbContext : DbContext
    {
        public FlowersDbContext(DbContextOptions<FlowersDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<User>(entity => {
                entity.HasIndex(u => u.Username).IsUnique();
            });

            //builder.Entity<UserUserRole>(entity => {
            //    entity.HasKey(u => new { u.UserId, u.UserRoleId }).IsUnique();
            //});

            builder.Entity<Comment>()
                .HasOne(f => f.Flower)
                .WithMany(c => c.Comments)
                .OnDelete(DeleteBehavior.Cascade);

            builder.Entity<Flower>()
                .HasOne(u => u.Owner)
                .WithMany(f => f.Flowers)
                .OnDelete(DeleteBehavior.Cascade);
        }

        // DbSet = Repository
        // DbSet = O tabela din baza de date
        public DbSet<Flower> Flowers { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }
        public DbSet<UserUserRole> UserUserRoles { get; set; }
    }
}
